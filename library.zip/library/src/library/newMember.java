package library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class newMember extends javax.swing.JFrame {

    public newMember() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel140 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        combo_CourseTitle = new javax.swing.JComboBox<>();
        combo_Course = new javax.swing.JComboBox<>();
        txt1 = new javax.swing.JTextField();
        txt2 = new javax.swing.JTextField();
        jLabel143 = new javax.swing.JLabel();
        jLabel144 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("DELETE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(51, 51, 51));
        jButton2.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("UPDATE");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(51, 51, 51));
        jButton3.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("ADD");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel140.setBackground(new java.awt.Color(51, 255, 255));
        jLabel140.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel140.setText("Student ID");

        jLabel142.setBackground(new java.awt.Color(51, 255, 255));
        jLabel142.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel142.setText("Name");

        combo_CourseTitle.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        combo_CourseTitle.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Diploma", "HND", "BSC", "MSC" }));
        combo_CourseTitle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_CourseTitleActionPerformed(evt);
            }
        });

        combo_Course.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        combo_Course.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Software Engineering", "Network Engineering", "System Design" }));

        txt1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        txt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt1ActionPerformed(evt);
            }
        });

        txt2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N

        jLabel143.setBackground(new java.awt.Color(51, 255, 255));
        jLabel143.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel143.setText("Course Title");

        jLabel144.setBackground(new java.awt.Color(51, 255, 255));
        jLabel144.setFont(new java.awt.Font("Verdana", 0, 17)); // NOI18N
        jLabel144.setText("Course");

        jButton4.setBackground(new java.awt.Color(242, 242, 242));
        jButton4.setFont(new java.awt.Font("Segoe UI Variable", 0, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/arrow-small-left.png"))); // NOI18N
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(203, 203, 203)
                        .addComponent(jButton2)
                        .addGap(30, 30, 30)
                        .addComponent(jButton3)
                        .addGap(32, 32, 32)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel140)
                            .addComponent(jLabel142)
                            .addComponent(jLabel144)
                            .addComponent(jLabel143))
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txt1)
                                .addComponent(txt2, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(combo_Course, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(combo_CourseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(195, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel140)
                            .addComponent(txt1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(43, 43, 43)
                        .addComponent(jLabel142)
                        .addGap(43, 43, 43)
                        .addComponent(jLabel143)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel144)
                        .addGap(78, 78, 78))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(txt2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(combo_CourseTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(combo_Course, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(73, 73, 73)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    public void connect(){
    
    
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
     String url = "jdbc:mysql://localhost/library";
    String user = "root";
    String pwd = "Shane@123";
    
    // Prepare the insert query
    String query =("delete from students where student_id=?");
    
    // Retrieve values from text fields
    String student_id = txt1.getText();


   
    try {
        Connection com = DriverManager.getConnection(url, user, pwd);
        PreparedStatement stmt = com.prepareStatement(query);
        
        stmt.setString(1, student_id);


        
        // Execute the insert query
        int rows = stmt.executeUpdate();
        
        // Show success message
        JOptionPane.showMessageDialog(this, " record deleted successful!");
    } catch (SQLException e) {
        // Handle SQL exceptions
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());

    }                                        
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    String uri = "jdbc:mysql://localhost/library";
    String user = "root";
    String pwd = "Shane@123";
    
    // Prepare the insert query
    String query ="update students set name=?,course_title=?,Course=? where student_id=?";
    
    // Retrieve values from text fields
    String student_id = txt1.getText();
    String name =txt2.getText();
    String course_title = combo_CourseTitle.getSelectedItem().toString();
    String course =combo_Course.getSelectedItem().toString();

    

    try {
        Connection com = DriverManager.getConnection(uri, user, pwd);
        PreparedStatement stmt = com.prepareStatement(query);
        
        
        stmt.setString(1, name);
        stmt.setString(2, course_title );
        stmt.setString(3, course);
        stmt.setString(4, student_id);

        
        // Execute the insert query
        int rows = stmt.executeUpdate();
        
        // Show success message
        JOptionPane.showMessageDialog(this, " updated successfully!");
    } catch (SQLException e) {
        // Handle SQL exceptions
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());

    }//GEN-LAST:event_jButton2ActionPerformed
    }
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    String uri = "jdbc:mysql://localhost/library";
    String user = "root";
    String pwd = "Shane@123";
    
    // Prepare the insert query
    String query = "INSERT INTO students VALUES (?, ?, ?, ?)";
    
    // Retrieve values from text fields
    String student_id = txt1.getText();
    String name =txt2.getText();
    String course_title = combo_CourseTitle.getSelectedItem().toString();
    String course =combo_Course.getSelectedItem().toString();

    

    try {
        Connection com = DriverManager.getConnection(uri, user, pwd);
        PreparedStatement stmt = com.prepareStatement(query);
        
        stmt.setString(1, student_id);
        stmt.setString(2, name);
        stmt.setString(3, course_title );
        stmt.setString(4, course);

        
        // Execute the insert query
        int rows = stmt.executeUpdate();
        
        // Show success message
        JOptionPane.showMessageDialog(this, " added successfully!");
    } catch (SQLException e) {
        // Handle SQL exceptions
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt1ActionPerformed

    private void combo_CourseTitleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_CourseTitleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combo_CourseTitleActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        Home HomeFrame = new Home();
        HomeFrame.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(newMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(newMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(newMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(newMember.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new newMember().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> combo_Course;
    private javax.swing.JComboBox<String> combo_CourseTitle;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel140;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JLabel jLabel143;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JTextField txt1;
    private javax.swing.JTextField txt2;
    // End of variables declaration//GEN-END:variables
}
